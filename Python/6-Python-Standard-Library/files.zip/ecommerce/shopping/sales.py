# from ecommerce.customer import contact
# contact.contact_customer()


# print("Sales initialized", __name__)


def calc_tax():
    pass


def calc_shipping():
    pass


# This is to execute this module as a Script
if __name__ == '__main__':
    print("Sales initialized")
    calc_shipping()
