print("Ecommerce initiliazed")
